// popup.js — AutoHC v2.0
const $ = id => document.getElementById(id);
const API_URL = 'https://hc-licencias.hc-gestiona.workers.dev';

const MESES_FULL = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

// ── Definición de toggles SYB ─────────────────────────────────────────────
const SYB_TOGGLES = [
  { id: 'antecedentes',          label: 'Antecedentes',                    pr: 1 },
  { id: 'revisionSistemas',      label: 'Revisión sistemas',               pr: 1 },
  { id: 'examenes',              label: 'Exámenes',                        pr: 2 },
  { id: 'medicamentos',          label: 'Medicamentos',                    pr: 2 },
  { id: 'interconsultas',        label: 'Interconsultas',                  pr: 2 },
  { id: 'insumos',               label: 'Insumos',                         pr: 2 },
  { id: 'paquetes',              label: 'Paquetes',                        pr: 4 },
  { id: 'decisiones',            label: 'Decisiones',                      pr: 4 },
];

const TOGGLES_KEY = 'autohc_syb_toggles_v2';

const DEFAULT_TOGGLES = Object.fromEntries(SYB_TOGGLES.map(t => [t.id, false]));

async function getToggles() {
  return new Promise(r => chrome.storage.local.get([TOGGLES_KEY], d => r(d[TOGGLES_KEY] || DEFAULT_TOGGLES)));
}
async function saveToggles(toggles) {
  return new Promise(r => chrome.storage.local.set({ [TOGGLES_KEY]: toggles }, r));
}

// ── Detectar EPS de la pestaña activa ─────────────────────────────────────
async function detectarEPSActiva() {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (!tabs[0]) { resolve(null); return; }
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          if (document.querySelector('select[name="reason_item_selected_411"]')) return 'MTD';
          if (document.querySelector('select[name="reason_item_selected_1"]'))   return 'SYB';
          if (document.querySelector('select[name="reason_item_selected_259"]')) return 'SYB'; // teleconsulta
          return null;
        }
      }, results => {
        resolve(results?.[0]?.result || null);
      });
    });
  });
}

// ── Renderizar toggles en el popup ────────────────────────────────────────
async function renderToggles() {
  const eps = await detectarEPSActiva();
  const panel = $('panel-syb-toggles');

  if (eps !== 'SYB') {
    panel.classList.add('hidden');
    return;
  }

  panel.classList.remove('hidden');
  const toggles = await getToggles();
  const list = $('syb-toggles-list');
  list.innerHTML = '';

  SYB_TOGGLES.forEach(({ id, label }) => {
    const row = document.createElement('div');
    row.className = 'toggle-row';
    row.innerHTML = `
      <span class="toggle-label">${label}</span>
      <label class="toggle-switch">
        <input type="checkbox" id="toggle-${id}" ${toggles[id] ? 'checked' : ''}>
        <span class="toggle-track"></span>
      </label>`;
    list.appendChild(row);

    row.querySelector(`#toggle-${id}`).addEventListener('change', async e => {
      const current = await getToggles();
      current[id] = e.target.checked;
      await saveToggles(current);
    });
  });
}

function setHeaderInfo() {
  const now = new Date();
  $('hero-num').textContent = String(now.getMonth() + 1).padStart(2, '0');
  $('footer-period').textContent = `${MESES_FULL[now.getMonth()]} ${now.getFullYear()}`;
}

function setMetaStatus(state) {
  const dot = $('meta-dot');
  const txt = $('meta-status');
  dot.classList.remove('live', 'dead');
  if (state === 'live')      { dot.classList.add('live'); txt.textContent = 'EN LÍNEA'; }
  else if (state === 'dead') { dot.classList.add('dead'); txt.textContent = 'OFFLINE'; }
  else                       { txt.textContent = 'CONECTANDO'; }
}

function setStatusSquare(state) {
  const sq = $('status-square');
  sq.classList.remove('active', 'inactive', 'checking');
  if (state) sq.classList.add(state);
}

async function getSession() {
  return new Promise(r => chrome.storage.local.get(['hc_session'], d => r(d.hc_session || null)));
}

function sesionVigente(s) {
  if (!s) return false;
  if (!s.expira) {
    // compatibilidad con sesiones viejas (mes/año)
    const now = new Date();
    return s.mes === (now.getMonth() + 1) && s.anio === now.getFullYear();
  }
  return Date.now() < s.expira;
}

async function render() {
  const sesion = await getSession();
  if (sesionVigente(sesion)) {
    setStatusSquare('active');
    setMetaStatus('live');
    $('status-label').textContent = 'Licencia';
    $('status-value').textContent = 'Activa';
    $('status-value').classList.remove('muted');
    $('status-email').classList.remove('hidden');
    $('status-email').textContent = sesion.medico_id;
    $('panel-activate').classList.add('hidden');
    $('panel-active').classList.remove('hidden');
    $('panel-plantillas').classList.remove('hidden');
    renderToggles();
    cargarPlantillas();
  } else {
    setStatusSquare('inactive');
    setMetaStatus('dead');
    $('status-label').textContent = 'Estado';
    $('status-value').textContent = sesion ? 'Vencida' : 'Sin licencia';
    $('status-value').classList.add('muted');
    $('status-email').classList.add('hidden');
    $('panel-activate').classList.remove('hidden');
    $('panel-active').classList.add('hidden');
    $('panel-syb-toggles').classList.add('hidden');
    $('panel-plantillas').classList.add('hidden');
  }
}

$('activate-btn').addEventListener('click', async () => {
  const medicoId = $('key-id').value.trim().toLowerCase();
  const clave    = $('key-input').value.trim().toUpperCase();
  $('key-error').textContent = '';

  if (!medicoId) { $('key-error').textContent = 'Ingresa tu identificación.'; return; }
  if (!clave)    { $('key-error').textContent = 'Ingresa la clave del periodo.'; return; }

  const btn = $('activate-btn');
  btn.disabled = true;
  btn.querySelector('span:first-child').textContent = 'Verificando';
  setStatusSquare('checking');
  setMetaStatus('connecting');

  try {
    const resp = await fetch(`${API_URL}/validar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ clave, medico_id: medicoId })
    });
    const data = await resp.json();
    if (data.valida) {
      await new Promise(r => chrome.storage.local.set({
        hc_session: {
          clave,
          medico_id: medicoId,
          expira: data.expira || (Date.now() + 30 * 24 * 60 * 60 * 1000),
          ts: Date.now()
        }
      }, r));
      await render();
    } else {
      $('key-error').textContent = data.error || 'Clave inválida.';
      setStatusSquare('inactive');
      setMetaStatus('dead');
    }
  } catch(e) {
    $('key-error').textContent = 'Sin conexión al servidor.';
    setStatusSquare('inactive');
    setMetaStatus('dead');
  }

  btn.disabled = false;
  btn.querySelector('span:first-child').textContent = 'Activar';
});

$('deactivate-btn').addEventListener('click', async () => {
  await new Promise(r => chrome.storage.local.remove('hc_session', r));
  await render();
});

// Auto-format clave HC-MMYY-XXXXXX
$('key-input').addEventListener('input', e => {
  let v = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
  let f = '';
  if (v.length >= 1) f = v.slice(0, 2);
  if (v.length >= 3) f = v.slice(0, 2) + '-' + v.slice(2, 6);
  if (v.length >= 7) f = v.slice(0, 2) + '-' + v.slice(2, 6) + '-' + v.slice(6, 12);
  e.target.value = f;
});

setHeaderInfo();
render();

// ── Plantillas ────────────────────────────────────────────────────────────
const API_URL_PLANTILLAS = API_URL; // mismo worker

async function getSessionData() {
  return new Promise(r => chrome.storage.local.get(['hc_session'], d => r(d.hc_session || null)));
}

async function cargarPlantillas() {
  const sesion = await getSessionData();
  if (!sesionVigente(sesion)) return;
  const listEl = $('plantillas-list');
  try {
    const resp = await fetch(`${API_URL_PLANTILLAS}/plantillas?medico=${encodeURIComponent(sesion.medico_id)}&clave=${encodeURIComponent(sesion.clave)}`);
    const data = await resp.json();
    const plantillas = data.plantillas || [];
    if (plantillas.length === 0) {
      listEl.innerHTML = `<div style="font-family:'Geist Mono',monospace;font-size:10px;color:#999;text-align:center;padding:8px 0;">Sin plantillas. Crea una.</div>`;
      return;
    }
    listEl.innerHTML = plantillas.map(p => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid #e6e6e1;">
        <div>
          <div style="font-family:'Geist',sans-serif;font-size:12px;font-weight:500;color:#0a0a0a;letter-spacing:-0.01em;">${p.nombre}</div>
          <div style="font-family:'Geist Mono',monospace;font-size:9px;color:#999;">${p.eps || 'SYB'} · ${p.modalidad === 'telec' ? 'Teleconsulta' : 'Presencial'}</div>
        </div>
        <button class="btn-eliminar-plantilla" data-nombre="${p.nombre}"
          style="font-family:'Geist Mono',monospace;font-size:9px;color:#d4302a;background:none;border:none;cursor:pointer;padding:0;">✕</button>
      </div>`).join('');

    listEl.querySelectorAll('.btn-eliminar-plantilla').forEach(btn => {
      btn.addEventListener('click', async () => {
        const nombre = btn.dataset.nombre;
        if (!confirm(`¿Eliminar la plantilla "${nombre}"?`)) return;
        const s = await getSessionData();
        await fetch(`${API_URL_PLANTILLAS}/plantillas/${encodeURIComponent(nombre)}?medico=${encodeURIComponent(s.medico_id)}&clave=${encodeURIComponent(s.clave)}`, { method: 'DELETE' });
        cargarPlantillas();
      });
    });
  } catch(e) {
    listEl.innerHTML = `<div style="font-family:'Geist Mono',monospace;font-size:10px;color:#d4302a;text-align:center;padding:8px 0;">Error cargando plantillas</div>`;
  }
}

// ── Generar campos de examen físico dinámicamente ─────────────────────────
const EF_SYB_CAMPOS = [
  [79, 'Piel y faneras'], [80, 'Cabeza'], [81, 'Cuello'],
  [82, 'Tórax'], [83, 'Cardiovascular'], [84, 'Abdomen'],
  [85, 'Genitourinario'], [86, 'Extremidades'],
  [87, 'Neurológico'], [88, 'Otros hallazgos'],
];
const EF_MTD_CAMPOS = [
  [94, 'Condiciones generales'], [95, 'Cabeza y cuello'],
  [96, 'ORL'], [97, 'Tórax-Cardiopulmonar'], [98, 'Abdominal'],
  [99, 'Genitourinario'], [100, 'Osteomuscular'],
  [101, 'Neurológico'], [102, 'Piel y faneras'],
];

function generarCamposEF(campos, prefixId, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = campos.map(([id, label]) => `
    <div style="font-family:'Geist Mono',monospace;font-size:9px;color:#525252;text-transform:uppercase;letter-spacing:0.14em;margin-bottom:5px;">${label}</div>
    <textarea id="plantilla-ef-${prefixId}${id}" rows="2" placeholder="Dejar vacío para no copiar..."
      style="width:100%;box-sizing:border-box;padding:9px 12px;border:1.5px solid #d4d4cf;border-radius:0;font-family:'Geist',sans-serif;font-size:11px;outline:none;resize:vertical;margin-bottom:8px;"></textarea>
  `).join('');
}

// Inicializar campos al cargar el popup
generarCamposEF(EF_SYB_CAMPOS, '', 'plantilla-ef-syb-fields');
generarCamposEF(EF_MTD_CAMPOS, 'mtd-', 'plantilla-ef-mtd-fields');

// Mostrar/ocultar campos según EPS y modalidad
function actualizarCamposModalidad() {
  const eps     = $('plantilla-eps')?.value || 'SYB';
  const modal   = $('plantilla-modalidad')?.value;
  const efPres  = $('plantilla-ef-pres');
  const efMtd   = $('plantilla-ef-mtd');
  const efFull  = $('plantilla-ef-full');
  const modalEl = $('plantilla-modalidad');
  const planEl  = $('plantilla-plan')?.closest('div');

  if (eps === 'MTD') {
    if (efPres)  efPres.style.display  = 'none';
    if (efMtd)   efMtd.style.display   = '';
    if (modalEl) modalEl.parentElement.style.display = 'none';
    if (planEl)  planEl.style.display  = 'none'; // MTD no tiene Plan
  } else {
    if (efPres)  efPres.style.display  = '';
    if (efMtd)   efMtd.style.display   = 'none';
    if (modalEl) modalEl.parentElement.style.display = '';
    if (planEl)  planEl.style.display  = '';
    if (efFull)  efFull.style.display  = modal === 'pres' ? '' : 'none';
  }
}

$('plantilla-modalidad')?.addEventListener('change', actualizarCamposModalidad);
$('plantilla-eps')?.addEventListener('change', actualizarCamposModalidad);

// Toggle expandible examen físico detallado SYB
document.getElementById('btn-toggle-ef-detalle')?.addEventListener('click', () => {
  const detalle = $('plantilla-ef-detalle');
  const arrow   = $('ef-detalle-arrow');
  const visible = detalle.style.display !== 'none';
  detalle.style.display = visible ? 'none' : '';
  arrow.textContent = visible ? '▸' : '▾';
});

// Toggle expandible examen físico detallado MTD
document.getElementById('btn-toggle-ef-detalle-mtd')?.addEventListener('click', () => {
  const detalle = $('plantilla-ef-detalle-mtd');
  const arrow   = $('ef-detalle-arrow-mtd');
  const visible = detalle.style.display !== 'none';
  detalle.style.display = visible ? 'none' : '';
  arrow.textContent = visible ? '▸' : '▾';
});

// Abrir modal nueva plantilla
$('btn-nueva-plantilla')?.addEventListener('click', () => {
  $('modal-plantilla-titulo').textContent = 'Nueva plantilla';
  $('plantilla-nombre').value = '';
  $('plantilla-modalidad').value = 'pres';
  $('plantilla-motivo').value = '';
  $('plantilla-enfermedad').value = '';
  $('plantilla-talla').value = '';
  $('plantilla-peso').value = '';
  $('plantilla-fr').value = '';
  $('plantilla-fc').value = '';
  $('plantilla-tas').value = '';
  $('plantilla-tad').value = '';
  $('plantilla-temp').value = '';
  if ($('plantilla-aspecto')) $('plantilla-aspecto').value = '';
  if ($('plantilla-aspecto-mtd')) $('plantilla-aspecto-mtd').value = '';
  [79,80,81,82,83,84,85,86,87,88].forEach(id => {
    const el = $(`plantilla-ef-${id}`);
    if (el) el.value = '';
  });
  [94,95,96,97,98,99,100,101,102].forEach(id => {
    const el = $(`plantilla-ef-mtd-${id}`);
    if (el) el.value = '';
  });
  ['talla-mtd','peso-mtd','fr-mtd','fc-mtd','tas-mtd','tad-mtd','temp-mtd'].forEach(id => {
    const el = $(`plantilla-${id}`);
    if (el) el.value = '';
  });
  // Colapsar secciones detalladas
  const detalle = $('plantilla-ef-detalle');
  const arrow   = $('ef-detalle-arrow');
  if (detalle) detalle.style.display = 'none';
  if (arrow)   arrow.textContent = '▸';
  const detalleMtd = $('plantilla-ef-detalle-mtd');
  const arrowMtd   = $('ef-detalle-arrow-mtd');
  if (detalleMtd) detalleMtd.style.display = 'none';
  if (arrowMtd)   arrowMtd.textContent = '▸';
  $('plantilla-analisis').value = '';
  $('plantilla-plan').value = '';
  $('plantilla-error').textContent = '';
  actualizarCamposModalidad();
  $('modal-plantilla').classList.remove('hidden');
});

$('btn-cerrar-modal-plantilla')?.addEventListener('click', () => {
  $('modal-plantilla').classList.add('hidden');
});

// Guardar plantilla
$('btn-guardar-plantilla')?.addEventListener('click', async () => {
  const nombre    = $('plantilla-nombre').value.trim();
  const eps       = $('plantilla-eps').value;
  const modalidad = eps === 'MTD' ? 'pres' : $('plantilla-modalidad').value;
  const errEl     = $('plantilla-error');
  errEl.textContent = '';

  if (!nombre) { errEl.textContent = 'Ingresa un nombre para la plantilla.'; return; }

  let campos = {
    motivo:     $('plantilla-motivo').value.trim(),
    enfermedad: $('plantilla-enfermedad').value.trim(),
    analisis:   $('plantilla-analisis').value.trim(),
    plan:       $('plantilla-plan').value.trim(),
  };

  if (eps === 'SYB') {
    campos.talla = $('plantilla-talla').value.trim();
    campos.peso  = $('plantilla-peso').value.trim();
    if (modalidad === 'pres') {
      campos.fr      = $('plantilla-fr').value.trim();
      campos.fc      = $('plantilla-fc').value.trim();
      campos.tas     = $('plantilla-tas').value.trim();
      campos.tad     = $('plantilla-tad').value.trim();
      campos.temp    = $('plantilla-temp').value.trim();
      campos.aspecto = $('plantilla-aspecto')?.value || '';
      campos.ef = {};
      [79,80,81,82,83,84,85,86,87,88].forEach(id => {
        const val = $(`plantilla-ef-${id}`)?.value.trim() || '';
        if (val) campos.ef[id] = val;
      });
    }
  } else {
    // MTD
    campos.talla   = $('plantilla-talla-mtd').value.trim();
    campos.peso    = $('plantilla-peso-mtd').value.trim();
    campos.fr      = $('plantilla-fr-mtd').value.trim();
    campos.fc      = $('plantilla-fc-mtd').value.trim();
    campos.tas     = $('plantilla-tas-mtd').value.trim();
    campos.tad     = $('plantilla-tad-mtd').value.trim();
    campos.temp    = $('plantilla-temp-mtd').value.trim();
    campos.aspecto = $('plantilla-aspecto-mtd')?.value || '';
    campos.ef = {};
    [94,95,96,97,98,99,100,101,102].forEach(id => {
      const val = $(`plantilla-ef-mtd-${id}`)?.value.trim() || '';
      if (val) campos.ef[id] = val;
    });
  }

  const sesion = await getSessionData();
  if (!sesionVigente(sesion)) { errEl.textContent = 'Sesión inválida.'; return; }

  const btnGuardar = $('btn-guardar-plantilla');
  btnGuardar.textContent = 'Guardando...';
  btnGuardar.disabled = true;

  try {
    const resp = await fetch(`${API_URL_PLANTILLAS}/plantillas`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ medico_id: sesion.medico_id, clave: sesion.clave, nombre, modalidad, eps, campos })
    });
    const data = await resp.json();
    if (!data.ok) { errEl.textContent = data.error || 'Error al guardar.'; return; }
    $('modal-plantilla').classList.add('hidden');
    cargarPlantillas();
  } catch(e) {
    errEl.textContent = 'Sin conexión al servidor.';
  } finally {
    btnGuardar.textContent = 'Guardar plantilla';
    btnGuardar.disabled = false;
  }
});
