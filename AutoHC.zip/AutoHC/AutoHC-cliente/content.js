// content.js — AutoHC v3
// Corre en el "isolated world" — tiene acceso a chrome.storage pero NO a tinymce/jQuery
// Su trabajo: validar licencia, mostrar el botón, e inyectar page-inject.js cuando el usuario activa

(async function () {
  'use strict';

  const API_URL = 'https://hc-licencias.hc-gestiona.workers.dev';

  // ── Sesión local ────────────────────────────────────────────────────────
  async function getSession() {
    return new Promise(resolve => chrome.storage.local.get(['hc_session'], r => resolve(r.hc_session || null)));
  }
  async function saveSession(clave, medicoId, diasDuracion = 30) {
    const expira = Date.now() + diasDuracion * 24 * 60 * 60 * 1000;
    return new Promise(resolve => chrome.storage.local.set({
      hc_session: { clave, medico_id: medicoId, expira, ts: Date.now() }
    }, resolve));
  }
  function sesionVigente(s) {
    if (!s) return false;
    if (!s.expira) {
      // compatibilidad con sesiones viejas (mes/año)
      const now = new Date();
      return s.mes === (now.getMonth() + 1) && s.anio === now.getFullYear();
    }
    return Date.now() < s.expira;
  }
  async function validarEnServidor(clave, medicoId) {
    try {
      const resp = await fetch(`${API_URL}/validar`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clave, medico_id: medicoId })
      });
      return await resp.json();
    } catch(e) {
      return { valida: false, error: 'Sin conexión al servidor de licencias.' };
    }
  }

  // ── Inyectar el script en el contexto de la página ──────────────────────
  function inyectarPageScript() {
    if (document.getElementById('autohc-page-script')) return Promise.resolve();
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.id = 'autohc-page-script';
      script.src = chrome.runtime.getURL('page-inject.js');
      script.onload = () => { script.remove(); resolve(); };
      script.onerror = () => { console.error('[AutoHC] Error inyectando page-inject.js'); resolve(); };
      (document.head || document.documentElement).appendChild(script);
    });
  }

  // ── Detectar EPS (también funciona desde el isolated world) ─────────────
  function detectarEPS() {
    if (document.querySelector('select[name="reason_item_selected_411"]')) return 'MTD';
    if (document.querySelector('select[name="reason_item_selected_1"]'))   return 'SYB';
    if (document.querySelector('select[name="reason_item_selected_259"]')) return 'SYB'; // plantilla teleconsulta
    return null;
  }

  // ── Cargar fonts ────────────────────────────────────────────────────────
  function ensureFonts() {
    if (document.getElementById('hc-fonts')) return;
    const link = document.createElement('link');
    link.id = 'hc-fonts';
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Geist:wght@400;500;600;700;800&family=Geist+Mono:wght@400;500;600&display=swap';
    document.head.appendChild(link);
  }

  // ── Activar botón (cuando hay licencia válida) ──────────────────────────
  async function activarBoton(btn) {
    ensureFonts();
    btn.innerHTML = `<span style="display:inline-flex;align-items:center;gap:9px;">
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none" style="flex-shrink:0;">
        <path d="M3 7 L6 10 L11 4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <span style="font-family:'Geist',sans-serif;font-weight:600;letter-spacing:-0.01em;font-size:13px;">Auto<span style="font-family:'Instrument Serif',serif;font-style:italic;font-weight:400;">HC</span></span>
    </span>`;
    btn.style.background = '#0040dd';
    btn.style.color = 'white';
    btn.style.border = 'none';
    btn.style.borderRadius = '0';
    btn.style.opacity = '1';
    btn.style.cursor = 'pointer';
    btn.disabled = false;
    btn.style.boxShadow = '0 8px 24px rgba(0,64,221,0.25), 0 0 0 1px rgba(0,64,221,0.1)';
    btn.onmouseenter = () => { btn.style.background = '#003ab8'; };
    btn.onmouseleave = () => { btn.style.background = '#0040dd'; };

    // Asegurar que page-inject.js está cargado, y luego disparar el evento
    btn.onclick = async () => {
      const modo = detectarEPS();
      if (!modo) {
        alert('⚠️ No se pudo detectar el tipo de historia clínica.');
        return;
      }
      await inyectarPageScript();
      let toggles = {};
      if (modo === 'SYB') {
        toggles = await new Promise(r => chrome.storage.local.get(['autohc_syb_toggles_v2'], d => r(d.autohc_syb_toggles_v2 || {})));
      }
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('autohc:start', { detail: { modo, toggles } }));
      }, 100);
    };

    // ── Botón secundario "Plantilla" ────────────────────────────────
    if (!document.getElementById('btn-plantilla-hc')) {
      const btnP = document.createElement('button');
      btnP.id = 'btn-plantilla-hc';
      btnP.style.cssText = `position:fixed;bottom:24px;right:${200 + 24 + 8}px;z-index:99999;background:#fafafa;color:#0a0a0a;border:1.5px solid #d4d4cf;border-radius:0;padding:12px 16px;font-size:13px;font-family:'Geist',sans-serif;font-weight:600;cursor:pointer;transition:all 0.2s ease;white-space:nowrap;`;
      btnP.innerHTML = `📋 <span style="font-family:'Geist',sans-serif;font-size:12px;letter-spacing:-0.01em;">Plantilla</span>`;
      btnP.onmouseenter = () => { btnP.style.borderColor = '#0040dd'; btnP.style.color = '#0040dd'; };
      btnP.onmouseleave = () => { btnP.style.borderColor = '#d4d4cf'; btnP.style.color = '#0a0a0a'; };
      btnP.onclick = async () => {
        const modo = detectarEPS();
        if (!modo || modo !== 'SYB') { alert('⚠️ Las plantillas solo están disponibles en SYB.'); return; }
        await inyectarPageScript();
        const sesion = await getSession();
        setTimeout(() => {
          window.dispatchEvent(new CustomEvent('autohc:plantilla', { detail: { sesion } }));
        }, 100);
      };
      document.body.appendChild(btnP);
    }
  }

  // ── Listener: cuando page-inject termina, restaurar el botón ────────────
  window.addEventListener('autohc:done', () => {
    const btn = document.getElementById('btn-copiar-hc');
    if (btn) {
      setTimeout(() => activarBoton(btn), 4000);
    }
  });

  // ── Modal de activación ─────────────────────────────────────────────────
  function mostrarModalActivacion(btn) {
    if (document.getElementById('hc-modal')) return;
    ensureFonts();
    const modal = document.createElement('div');
    modal.id = 'hc-modal';
    modal.style.cssText = `position:fixed;inset:0;z-index:999999;background:rgba(10,10,10,0.5);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;font-family:'Geist',-apple-system,sans-serif;animation:hcFadeIn 0.25s ease;`;

    if (!document.getElementById('hc-modal-style')) {
      const st = document.createElement('style');
      st.id = 'hc-modal-style';
      st.textContent = `
        @keyframes hcFadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes hcSlideUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        #hc-modal-card input::placeholder { color: #999 !important; }
        #hc-modal-card input:focus { border-color: #0040dd !important; box-shadow: 0 0 0 3px #e6ecff !important; }
      `;
      document.head.appendChild(st);
    }

    const now = new Date();
    const heroNum = String(now.getMonth() + 1).padStart(2, '0');

    modal.innerHTML = `
      <div id="hc-modal-card" style="background:#fafafa;border-radius:0;padding:0;width:360px;box-shadow:0 32px 80px rgba(0,0,0,0.25);position:relative;color:#0a0a0a;animation:hcSlideUp 0.35s cubic-bezier(0.16,1,0.3,1);overflow:hidden;-webkit-font-smoothing:antialiased;">
        <div style="display:flex;justify-content:space-between;padding:14px 22px 10px;border-bottom:1px solid #e6e6e1;font-family:'Geist Mono',monospace;font-size:10px;color:#999;letter-spacing:0.04em;text-transform:uppercase;">
          <div><strong style="color:#0a0a0a;font-weight:600;">HC.001</strong> &nbsp;/&nbsp; v1.0</div>
          <button id="hc-modal-close" style="background:transparent;border:none;color:#999;cursor:pointer;font-size:18px;padding:0;line-height:1;font-family:'Geist',sans-serif;">×</button>
        </div>

        <div style="padding:28px 22px 14px;position:relative;">
          <div style="font-family:'Instrument Serif',serif;font-style:italic;font-size:80px;line-height:0.9;color:#0040dd;letter-spacing:-0.04em;position:absolute;top:18px;right:20px;opacity:0.16;pointer-events:none;user-select:none;">${heroNum}</div>
          <h1 style="font-family:'Geist',sans-serif;font-weight:800;font-size:40px;letter-spacing:-0.045em;line-height:0.95;color:#0a0a0a;margin:0;">Auto<span style="font-family:'Instrument Serif',serif;font-style:italic;font-weight:400;letter-spacing:-0.02em;color:#0040dd;">HC</span></h1>
          <div style="font-family:'Geist Mono',monospace;font-size:10px;color:#525252;letter-spacing:0.18em;text-transform:uppercase;margin-top:12px;">
            <span style="font-size:7px;color:#0040dd;margin-right:8px;letter-spacing:0;">◢</span>Activación de licencia
          </div>
        </div>

        <div style="padding:8px 22px 20px;border-top:1px dashed #d4d4cf;">
          <div style="margin-top:14px;">
            <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px;">
              <span style="font-family:'Geist Mono',monospace;font-size:10px;color:#525252;text-transform:uppercase;letter-spacing:0.14em;font-weight:500;">Identificación</span>
              <span style="font-family:'Instrument Serif',serif;font-style:italic;font-size:14px;color:#0040dd;opacity:0.7;">i</span>
            </div>
            <input id="hc-id-input" type="text" placeholder="medico@correo.com" autocomplete="off" spellcheck="false"
              style="width:100%;box-sizing:border-box;padding:12px 14px;background:white;border:1.5px solid #d4d4cf;border-radius:0;font-family:'Geist Mono',monospace;font-size:13px;color:#0a0a0a;outline:none;letter-spacing:0;transition:all 0.2s;"/>
          </div>

          <div style="margin-top:14px;">
            <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px;">
              <span style="font-family:'Geist Mono',monospace;font-size:10px;color:#525252;text-transform:uppercase;letter-spacing:0.14em;font-weight:500;">Clave del periodo</span>
              <span style="font-family:'Instrument Serif',serif;font-style:italic;font-size:14px;color:#0040dd;opacity:0.7;">ii</span>
            </div>
            <input id="hc-key-input" type="text" placeholder="HC-MMYY-XXXXXX" autocomplete="off" spellcheck="false" maxlength="14"
              style="width:100%;box-sizing:border-box;padding:12px 14px;background:white;border:1.5px solid #d4d4cf;border-radius:0;font-family:'Geist Mono',monospace;font-size:14px;color:#0a0a0a;outline:none;letter-spacing:0.14em;text-align:center;text-transform:uppercase;font-weight:600;transition:all 0.2s;"/>
          </div>

          <div id="hc-key-error" style="font-family:'Geist Mono',monospace;font-size:11px;color:#d4302a;min-height:16px;margin:10px 0 0;letter-spacing:0;"></div>

          <button id="hc-activar-btn" style="width:100%;padding:14px 18px;background:#0040dd;color:white;border:none;border-radius:0;cursor:pointer;font-family:'Geist',sans-serif;font-size:13px;font-weight:600;letter-spacing:-0.01em;display:flex;align-items:center;justify-content:center;gap:10px;transition:all 0.2s;margin-top:14px;">
            <span>Activar</span>
            <span style="font-size:14px;">→</span>
          </button>
        </div>

        <div style="border-top:1px solid #e6e6e1;padding:12px 22px;display:flex;justify-content:space-between;align-items:center;background:#f0f0ec;">
          <div style="font-family:'Geist',sans-serif;font-size:11px;font-weight:600;color:#0a0a0a;letter-spacing:-0.01em;">Auto<span style="font-family:'Instrument Serif',serif;font-style:italic;font-weight:400;color:#0040dd;">HC</span></div>
          <div style="font-family:'Geist Mono',monospace;font-size:9px;color:#999;letter-spacing:0.14em;text-transform:uppercase;">¿Sin clave? Contacta al admin</div>
        </div>
      </div>`;
    document.body.appendChild(modal);

    setTimeout(() => document.getElementById('hc-id-input')?.focus(), 100);

    document.getElementById('hc-modal-close').addEventListener('click', () => modal.remove());
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });

    const activarBtn = document.getElementById('hc-activar-btn');
    activarBtn.onmouseenter = () => { if (!activarBtn.disabled) activarBtn.style.background = '#003ab8'; };
    activarBtn.onmouseleave = () => { if (!activarBtn.disabled) activarBtn.style.background = '#0040dd'; };

    document.getElementById('hc-activar-btn').addEventListener('click', async () => {
      const medicoId = document.getElementById('hc-id-input').value.trim().toLowerCase();
      const clave    = document.getElementById('hc-key-input').value.trim().toUpperCase();
      const errEl    = document.getElementById('hc-key-error');
      const activarBtnInner = document.getElementById('hc-activar-btn');

      if (!medicoId) { errEl.textContent = 'Ingresa tu identificación.'; return; }
      if (!clave)    { errEl.textContent = 'Ingresa la clave.'; return; }

      activarBtnInner.querySelector('span').textContent = 'Verificando...';
      activarBtnInner.disabled = true;

      const resultado = await validarEnServidor(clave, medicoId);

      if (!resultado.valida) {
        errEl.textContent = resultado.error || 'Clave inválida o vencida.';
        activarBtnInner.querySelector('span').textContent = 'Activar';
        activarBtnInner.disabled = false;
        return;
      }

      await new Promise(resolve => chrome.storage.local.set({
        hc_session: {
          clave,
          medico_id: medicoId,
          expira: resultado.expira || (Date.now() + 30 * 24 * 60 * 60 * 1000),
          ts: Date.now()
        }
      }, resolve));
      modal.remove();
      await activarBoton(btn);
    });

    const claveInput = document.getElementById('hc-key-input');
    claveInput.addEventListener('input', e => {
      let v = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
      let f = '';
      if (v.length >= 1) f = v.slice(0, 2);
      if (v.length >= 3) f = v.slice(0, 2) + '-' + v.slice(2, 6);
      if (v.length >= 7) f = v.slice(0, 2) + '-' + v.slice(2, 6) + '-' + v.slice(6, 12);
      e.target.value = f;
    });
  }

  // ── Crear botón flotante ────────────────────────────────────────────────
  async function crearBoton() {
    if (document.getElementById('btn-copiar-hc')) return;
    ensureFonts();

    const btn = document.createElement('button');
    btn.id = 'btn-copiar-hc';
    btn.style.cssText = `position:fixed;bottom:24px;right:24px;z-index:99999;color:white;border:none;border-radius:0;padding:12px 20px;font-size:14px;font-weight:bold;cursor:pointer;transition:all 0.2s ease;text-align:center;min-width:200px;`;
    document.body.appendChild(btn);

    const sesion = await getSession();
    if (sesionVigente(sesion)) {
      activarBoton(btn);
      // Pre-cargar el page-inject para que el primer clic sea instantáneo
      inyectarPageScript();
      return;
    }

    // Sin sesión válida — botón bloqueado
    btn.innerHTML = `<span style="display:inline-flex;align-items:center;gap:9px;">
      <svg width="13" height="13" viewBox="0 0 13 13" fill="none" style="flex-shrink:0;">
        <rect x="2" y="6" width="9" height="6" rx="0" stroke="#525252" stroke-width="1.3"/>
        <path d="M4 6 V4 a2.5 2.5 0 0 1 5 0 V6" stroke="#525252" stroke-width="1.3" stroke-linecap="round"/>
      </svg>
      <span style="font-family:'Geist',sans-serif;font-weight:600;letter-spacing:-0.01em;font-size:13px;color:#0a0a0a;">Auto<span style="font-family:'Instrument Serif',serif;font-style:italic;font-weight:400;color:#0040dd;">HC</span> · Sin licencia</span>
    </span>`;
    btn.style.background = '#fafafa';
    btn.style.color = '#0a0a0a';
    btn.style.border = '1.5px solid #d4d4cf';
    btn.style.boxShadow = '0 4px 14px rgba(0,0,0,0.08)';
    btn.onmouseenter = () => { btn.style.background = '#f0f0ec'; btn.style.borderColor = '#0040dd'; };
    btn.onmouseleave = () => { btn.style.background = '#fafafa'; btn.style.borderColor = '#d4d4cf'; };
    btn.addEventListener('click', () => mostrarModalActivacion(btn));
  }

  window.addEventListener('load', () => setTimeout(crearBoton, 1800));
})();
