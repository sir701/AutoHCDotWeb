// page-inject.js — Se ejecuta en el contexto de la página (acceso a tinymce y jQuery)
// El content.js lo inyecta cuando el usuario hace clic en el botón

(function() {
  'use strict';

  // Si ya está inyectado, no duplicar
  if (window.__autoHCInjected) return;
  window.__autoHCInjected = true;

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const BASE = 'https://saludgestiona.com/business/edit-records-medical-history/';

  function log(msg) {
    const btn = document.getElementById('btn-copiar-hc');
    if (btn) btn.textContent = '⏳ ' + msg;
    console.log('[AutoHC]', msg);
  }

  function setVal(el, val) {
    if (!el || val === undefined || val === null) return false;
    el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function appendVal(el, extra) {
    if (!el || !extra) return;
    const base = (el.value || '').replace(/\s+$/, '');
    el.value = base + (base.length ? '\n\n' : '') + extra;
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function setTinyOrTextarea(name, value) {
    if (value === undefined || value === null) return false;
    if (window.tinymce) {
      const ed = window.tinymce.get(name);
      if (ed) { ed.setContent(value || ''); ed.save(); return true; }
    }
    const el = document.querySelector(`textarea[name="${name}"]`);
    return setVal(el, value);
  }

  function syncAllTinymce() {
    if (window.tinymce && window.tinymce.editors) {
      window.tinymce.editors.forEach(e => { try { e.save(); } catch(_){} });
    }
  }

  const decodeB64 = (b64) => { try { return atob(b64); } catch(e) { return null; } };

  function getPatientId() {
    const link = document.querySelector('a[href*="patients-list/"]');
    if (!link) return null;
    const b64 = link.getAttribute('href').split('/').pop();
    const decoded = decodeB64(b64);
    const m = decoded && decoded.match(/id=(\d+)/);
    return m ? m[1] : null;
  }

  function detectarEPS() {
    if (document.querySelector('select[name="reason_item_selected_411"]')) return 'MTD';
    if (document.querySelector('select[name="reason_item_selected_1"]'))   return 'SYB';
    if (document.querySelector('select[name="reason_item_selected_259"]')) return 'SYB'; // apoyo telefonico / teleconsulta / videoconsulta
    return null;
  }

  // ── AJAX monitor (SYB) ──────────────────────────────────────────────────
  function installAjaxMonitor() {
    if (window.__hcAjaxMonitor) return;
    window.__hcAjaxInFlight = 0;
    if (window.jQuery) {
      jQuery(document).ajaxSend(() => { window.__hcAjaxInFlight++; });
      jQuery(document).ajaxComplete(() => { window.__hcAjaxInFlight = Math.max(0, window.__hcAjaxInFlight - 1); });
    }
    window.__hcAjaxMonitor = true;
  }

  async function waitAjaxIdle(timeoutMs = 8000) {
    await sleep(200);
    const start = Date.now();
    while (window.__hcAjaxInFlight > 0 && Date.now() - start < timeoutMs) await sleep(100);
    await sleep(250);
  }

  // ── Stream fetch ────────────────────────────────────────────────────────
  async function streamFetch(url, { maxBytes = 200000, stopWhen } = {}) {
    const ctrl = new AbortController();
    let buf = '';
    try {
      const resp = await fetch(url, { credentials: 'same-origin', signal: ctrl.signal });
      const reader = resp.body.getReader();
      const dec = new TextDecoder();
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        if (stopWhen && stopWhen(buf)) break;
        if (buf.length >= maxBytes) break;
      }
    } catch (_) {}
    finally { try { ctrl.abort(); } catch(_) {} }
    return buf;
  }

  async function fetchPage(url) {
    const resp = await fetch(url, { credentials: 'same-origin' });
    return new DOMParser().parseFromString(await resp.text(), 'text/html');
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SCRIPT MTD (original tal cual)
  // ══════════════════════════════════════════════════════════════════════════
  const MODALIDADES_OMITIR = [
    'VALORACION INTRAHOSPITALARIA','VALORACIÓN INTRAHOSPITALARIA',
    'NOTA ACLARATORIA','EGRESO POR FALLECIMIENTO','TELECONSULTA','VIDEOCONSULTA'
  ];
  const EXCLUIR_TEXTO = [
    'TELECONSULTA','VIDEOCONSULTA','TRABAJO SOCIAL','ENFERMERIA','ENFERMERÍA',
    'NUTRICIÓN','NUTRICION','FORMATO DE CORRECCIÓN','FORMATO DE CORRECCION',
    'NOTA ACLARATORIA','EGRESO POR FALLECIMIENTO',
    'VALORACION INTRAHOSPITALARIA','VALORACIÓN INTRAHOSPITALARIA'
  ];
  const textoExcluido = (t) => EXCLUIR_TEXTO.some(x => t.includes(x));

  function extraerModalidadDeHtml(html) {
    const idx = html.indexOf('reason_item_selected_411');
    if (idx === -1) return null;
    const end = html.indexOf('</select>', idx);
    if (end === -1) return null;
    const block = html.substring(idx, end);
    const m = block.match(/<option[^>]*selected[^>]*>\s*([^<]+?)\s*</i);
    return m ? m[1].trim().toUpperCase() : null;
  }

  function esPresencialTexto(modalidadUpper) {
    if (!modalidadUpper) return false;
    if (modalidadUpper === 'PRESENCIAL') return true;
    if (MODALIDADES_OMITIR.some(o => modalidadUpper.includes(o))) return false;
    return false;
  }

  async function verificarModalidad(b64part) {
    const html = await streamFetch(BASE + b64part, {
      maxBytes: 200000,
      stopWhen: (b) => b.indexOf('</select>', b.indexOf('reason_item_selected_411')) !== -1
                      && b.indexOf('reason_item_selected_411') !== -1
    });
    return extraerModalidadDeHtml(html);
  }

  async function descargarHCFuente(b64part) {
    const html = await streamFetch(BASE + b64part, {
      maxBytes: 450000,
      stopWhen: (b) => b.indexOf('id="tab6"') !== -1
    });
    return new DOMParser().parseFromString(html, 'text/html');
  }

  async function buscarHCFuente(patientId) {
    log('Listando historias clínicas...');
    const params = `patient=${patientId}&template_id=&filter=1&date=&from=&time_from=0%3A00&to=&time_to=23%3A59&code=&user=&spc=&center=&rate=&region=&status=&submit=1`;
    const listUrl = `https://saludgestiona.com/business/records-medical-history/${btoa(params)}`;
    const listResp = await fetch(listUrl, { credentials: 'same-origin' });
    const listHtml = await listResp.text();
    const listDoc = new DOMParser().parseFromString(listHtml, 'text/html');

    const rows = Array.from(listDoc.querySelectorAll('table tbody tr'));
    const candidatas = rows
      .filter(r => {
        const t = r.textContent.toUpperCase();
        return t.includes('MEDICINA GENERAL') && !textoExcluido(t);
      })
      .map(r => {
        const a = r.querySelector('a[href*="edit-records-medical-history"]');
        if (!a) return null;
        const b64 = a.getAttribute('href').split('/').pop();
        return { b64, id: decodeB64(b64) };
      })
      .filter(Boolean);

    const currentId = decodeB64(window.location.pathname.split('/').pop());
    const cola = candidatas.filter(c => c.id !== currentId);
    log(`Candidatas: ${cola.length}. Verificando la más reciente primero...`);

    // 🔁 Secuencial: la tabla viene ordenada por fecha DESC (más reciente arriba).
    // Recorremos una por una. La primera que cumpla PRESENCIAL gana.
    for (let i = 0; i < cola.length; i++) {
      try {
        const modal = await verificarModalidad(cola[i].b64);
        log(`  [${i + 1}/${cola.length}] ${cola[i].id} → ${modal || '?'}`);
        if (esPresencialTexto(modal)) {
          log(`HC PRESENCIAL: ${(cola[i].id || '').trim()} — descargando fuente...`);
          return await descargarHCFuente(cola[i].b64);
        }
      } catch(_) {}
    }
    return null;
  }

  async function guardarForm(formId, waitMs = 1400) {
    const form = document.getElementById(formId);
    if (!form) { console.warn('[AutoHC] form no encontrado:', formId); return false; }
    syncAllTinymce();
    if (window.jQuery) window.jQuery(form).trigger('submit');
    else { const b = form.querySelector('button[type="submit"]'); if (b) b.click(); }
    await sleep(waitMs);
    return true;
  }

  async function esperarForm(formId, timeout = 2000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const f = document.getElementById(formId);
      if (f) return f;
      await sleep(100);
    }
    return document.getElementById(formId);
  }

  async function iniciarCopiaMTD() {
    const btn = document.getElementById('btn-copiar-hc');
    btn.disabled = true;
    btn.style.background = '#e65100';
    const tStart = performance.now();

    try {
      const patientId = getPatientId();
      if (!patientId) { alert('❌ No se identificó paciente.'); return; }

      const fuenteDoc = await buscarHCFuente(patientId);
      if (!fuenteDoc) { alert('❌ Sin HC Medicina General PRESENCIAL previa.'); return; }
      console.log(`[AutoHC] Búsqueda+descarga: ${Math.round(performance.now()-tStart)} ms`);

      // ── TAB 1 ───────────────────────────────────────────────────────────
      log('Pegando Motivo...');
      document.querySelector('a[href="#tab1"]')?.click();

      const tab1Dest = document.querySelector('#tab1');
      const tab1Src  = fuenteDoc.querySelector('#tab1');

      setVal(tab1Dest.querySelector('select[name="reason_item_selected_411"]'), '602');
      setVal(tab1Dest.querySelector('select[name="reason_item_selected_245"]'), '253');
      setVal(
        tab1Dest.querySelector('textarea[name="reason_item_comments_2"]'),
        tab1Src?.querySelector('textarea[name="reason_item_comments_2"]')?.value || ''
      );
      setTinyOrTextarea(
        'reason_item_comments_1',
        tab1Src?.querySelector('textarea[name="reason_item_comments_1"]')?.value || ''
      );
      tab1Src?.querySelectorAll('input[type="text"], textarea').forEach(srcEl => {
        if (!srcEl.name || !srcEl.value) return;
        if (srcEl.name === 'reason_item_comments_1' || srcEl.name === 'reason_item_comments_2') return;
        const d = tab1Dest.querySelector(`[name="${srcEl.name}"]`);
        if (d && d.tagName === 'INPUT') setVal(d, srcEl.value);
      });

      log('Guardando Motivo...');
      await guardarForm('form_update_records_history_reason');

      // ── TAB 4: EXAMEN FÍSICO ────────────────────────────────────────────
      log('Pegando Examen físico...');
      document.querySelector('a[href="#tab4"]')?.click();

      const tab4Src = fuenteDoc.querySelector('#tab4');
      let tab4Dest  = document.querySelector('#tab4');

      const camposExamen = [
        'size','weight','breathing_frequency','heart_frequency',
        'blood_pressure_systolic','blood_pressure_diastolic',
        'temperature','abdominal_perimeter',
        'physic_exam_item_comments_402'
      ];
      camposExamen.forEach(name => {
        const src = tab4Src?.querySelector(`input[name="${name}"]`);
        const dest = tab4Dest.querySelector(`input[name="${name}"]`);
        if (src && dest && src.value !== '') setVal(dest, src.value);
      });
      setVal(tab4Dest.querySelector('select[name="physic_exam_item_selected_1691"]'), '2306');

      [94,95,96,97,98,99,100,101,102].forEach(id => {
        const src = tab4Src?.querySelector(`textarea[name="physic_exam_item_comments_${id}"]`);
        const dest = tab4Dest.querySelector(`textarea[name="physic_exam_item_comments_${id}"]`);
        if (src && dest) setVal(dest, src.value || '');
      });

      const facSrc  = tab4Src?.querySelector('select[name="fac"]');
      const facDest = tab4Dest.querySelector('select[name="fac"]');
      if (facSrc && facDest && facSrc.value) setVal(facDest, facSrc.value);

      log('Guardando Signos vitales...');
      await guardarForm('form_update_records_history_physic_exam', 1500);

      // BARTHEL
      await esperarForm('form_update_records_history_physic_exam_barthel', 1500);
      const barthelForm = document.getElementById('form_update_records_history_physic_exam_barthel');
      let barthelAplicado = false;
      if (barthelForm) {
        for (let i = 1; i <= 10; i++) {
          const src  = tab4Src?.querySelector(`select[name="val_bar_${i}"]`);
          const dest = barthelForm.querySelector(`select[name="val_bar_${i}"]`);
          if (src && dest && src.value) { setVal(dest, src.value); barthelAplicado = true; }
        }
        if (barthelAplicado) {
          log('Guardando Barthel...');
          await guardarForm('form_update_records_history_physic_exam_barthel', 1500);
        }
      }

      // ── TAB 5: ANÁLISIS ─────────────────────────────────────────────────
      log('Pegando Análisis...');
      document.querySelector('a[href="#tab5"]')?.click();

      const tab5Src = fuenteDoc.querySelector('#tab5');
      const tab5Dest = document.querySelector('#tab5');

      setTinyOrTextarea(
        'analysis_item_comments_6',
        tab5Src?.querySelector('textarea[name="analysis_item_comments_6"]')?.value || ''
      );
      setVal(tab5Dest.querySelector('select[name="analysis_item_selected_1692"]'), '2308');

      const conductaSrc = tab5Src?.querySelector('select[name="analysis_item_selected_425"]');
      const conductaDest = tab5Dest.querySelector('select[name="analysis_item_selected_425"]');
      if (conductaSrc && conductaDest && conductaSrc.value) setVal(conductaDest, conductaSrc.value);

      tab5Dest.querySelectorAll('select').forEach(s => {
        const lbl = (s.closest('div')?.querySelector('label')?.textContent || '').toUpperCase();
        if (lbl.includes('TIPO DE SEGUIMIENTO')) {
          const opt = Array.from(s.options).find(o => o.text.trim().toUpperCase() === 'MENSUAL');
          if (opt) setVal(s, opt.value);
        }
        if (lbl.includes('TIPO DE CONSULTA') && (lbl.includes('PROXIMO') || lbl.includes('PRÓXIMO'))) {
          const opt = Array.from(s.options).find(o => o.text.trim().toUpperCase() === 'PRESENCIAL');
          if (opt) setVal(s, opt.value);
        }
      });

      log('Guardando Análisis...');
      await guardarForm('form_update_medical_record_analysis');

      // ── TAB 6: DIAGNÓSTICOS ─────────────────────────────────────────────
      log('Diagnósticos — Histórico...');
      document.querySelector('a[href="#tab6"]')?.click();
      await sleep(300);

      const tab6 = document.querySelector('#tab6');
      const histBtn = Array.from(tab6.querySelectorAll('button'))
                           .find(b => b.textContent.trim() === 'Histórico');
      if (histBtn) histBtn.click();
      await sleep(900);

      const modal = document.querySelector('#diagnosis_modal');
      let reformulado = false;
      if (modal && (modal.classList.contains('show') || getComputedStyle(modal).display !== 'none')) {
        const filas = Array.from(modal.querySelectorAll('tbody tr'));
        for (const fila of filas) {
          const t = fila.textContent.toUpperCase();
          if (t.includes('MEDICINA GENERAL') && !textoExcluido(t)) {
            const addBtn = fila.querySelector('button.add_record_history_diagnosis');
            if (addBtn) { addBtn.click(); reformulado = true; await sleep(700); break; }
          }
        }
        const cerrar = modal.querySelector('button.close, [data-dismiss="modal"]');
        if (cerrar) cerrar.click();
        await sleep(300);
        if (!reformulado) alert('⚠️ No se halló fila MEDICINA GENERAL en el histórico.');
      } else {
        alert('⚠️ No se abrió el modal de Histórico.');
      }

      log('Guardando Diagnósticos...');
      await guardarForm('form_update_records_history_diagnosis');

      const totalMs = Math.round(performance.now() - tStart);
      console.log(`[AutoHC] Total: ${totalMs} ms`);
      btn.textContent = `✓ Listo · ${(totalMs/1000).toFixed(1)}s`;
      btn.dataset.hcDone = '1';
      // Avisar al content script para que reactive el botón
      window.dispatchEvent(new CustomEvent('autohc:done'));

    } catch (err) {
      console.error('[AutoHC]', err);
      alert('❌ ' + err.message);
      btn.dataset.hcDone = '1';
      window.dispatchEvent(new CustomEvent('autohc:done'));
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SCRIPT SYB
  // ══════════════════════════════════════════════════════════════════════════
  // ── Mapeo de campos entre plantillas ─────────────────────────────────────
  const CAMPO = {
    // Motivo
    modalidad:    { pres: 'reason_item_selected_1',   telec: 'reason_item_selected_259'  },
    motivo:       { pres: 'reason_item_comments_4',   telec: 'reason_item_comments_263'  },
    enfermedad:   { pres: 'reason_item_comments_10',  telec: 'reason_item_comments_264'  },
    acompNombre:  { pres: 'reason_item_comments_2',   telec: 'reason_item_comments_260'  },
    acompTel:     { pres: 'reason_item_comments_3',   telec: 'reason_item_comments_261'  },
    dispositivos: { pres: 'reason_item_items_256[]',  telec: 'reason_item_items_265[]'   },
    continuidad:  { pres: 'reason_item_selected_11',  telec: 'reason_item_selected_266'  },
    // Análisis
    analisis:     { pres: 'analysis_item_comments_27',  telec: 'analysis_item_comments_316' },
    seguimiento:  { pres: 'analysis_item_selected_31',  telec: 'analysis_item_selected_319' },
    proximoCtrl:  { pres: 'analysis_item_selected_34',  telec: 'analysis_item_selected_320' },
    // Plan
    plan:         { pres: 'plan_item_comments_258',   telec: 'plan_item_comments_322'    },
  };

  // Valores fijos por plantilla
  const VALS = {
    pres:  { modalPresencial: '9', modalHomecare: '3', mensual: '65', presencial: '72' },
    telec: { modalTelec: '242', modalVideo: '240', mensual: '278', presencial: '282', teleconsulta: '284' },
  };

  // Detecta la plantilla de un documento (fuente o destino)
  function detectarPlantilla(doc) {
    if (doc.querySelector('select[name="reason_item_selected_259"]')) return 'telec';
    if (doc.querySelector('select[name="reason_item_selected_1"]'))   return 'pres';
    return null;
  }

  // Helper: devuelve el name correcto según plantilla del doc
  function campo(key, plantilla) {
    return CAMPO[key]?.[plantilla] || null;
  }

  // Detecta la modalidad de una HC fuente (presencial, homecare, teleconsulta, videoconsulta)
  function detectarModalidad(hcDoc) {
    const plantilla = detectarPlantilla(hcDoc);
    if (plantilla === 'pres') {
      const sel = hcDoc.querySelector('select[name="reason_item_selected_1"]');
      const v = sel?.value;
      if (v === '9')  return 'presencial';
      if (v === '3')  return 'homecare';
      return null; // egreso, nota, etc.
    }
    if (plantilla === 'telec') {
      const sel = hcDoc.querySelector('select[name="reason_item_selected_259"]');
      const v = sel?.value;
      if (v === '242') return 'teleconsulta';
      if (v === '240') return 'videoconsulta';
      return null; // nota
    }
    return null;
  }

  // Verifica si una HC es válida como fuente según los toggles activos
  function modalidadPermitida(hcDoc, toggles) {
    const mod = detectarModalidad(hcDoc);
    if (!mod) return false;
    if (mod === 'presencial') return true; // siempre permitida
    if (mod === 'homecare'      && toggles.permitirHomecare)      return true;
    if (mod === 'teleconsulta'  && toggles.permitirTeleconsulta)  return true;
    if (mod === 'videoconsulta' && toggles.permitirVideoconsulta) return true;
    return false;
  }

  async function buscarHCFuenteSYB(patientId, toggles = {}) {
    log('Buscando historias del paciente...');
    const params = `patient=${patientId}&template_id=&filter=1&date=&from=&time_from=0%3A00&to=&time_to=23%3A59&code=&user=&spc=&center=&rate=&region=&status=&submit=1`;
    const listDoc = await fetchPage(`https://saludgestiona.com/business/records-medical-history/${btoa(params)}`);
    const rows = Array.from(listDoc.querySelectorAll('table tbody tr'));

    const currentId = decodeB64(window.location.pathname.split('/').pop());
    const plantDest = detectarPlantilla(document);

    const EXCLUIR_FILA = ['TRABAJO SOCIAL','ENFERMERIA','ENFERMERÍA','NUTRICIÓN','NUTRICION',
      'NOTA ACLARATORIA','EGRESO POR FALLECIMIENTO','FORMATO DE CORREC'];

    const CODIGO_TELEC = 'R7EU2Z';
    const CODIGO_PRES  = 'BCY3B3';

    function codPlantilla(fila) {
      return fila.querySelector('td:nth-child(5)')?.textContent?.trim() || '';
    }

    const candidatas = rows.filter(r => {
      const t = r.textContent.toUpperCase();
      const cod = codPlantilla(r);
      // Aceptar solo HCs con código de plantilla conocido (presencial o apoyo telefónico)
      if (cod !== CODIGO_TELEC && cod !== CODIGO_PRES) return false;
      // Excluir tipos no válidos como fuente
      if (EXCLUIR_FILA.some(x => t.includes(x))) return false;
      return true;
    });

    // TC destino → busca TC primero, presencial como fallback
    // Presencial/homecare destino → solo busca presenciales
    let ordenadas;
    if (plantDest === 'telec') {
      const telec = candidatas.filter(r => codPlantilla(r) === CODIGO_TELEC);
      const pres  = candidatas.filter(r => codPlantilla(r) === CODIGO_PRES);
      ordenadas = [...telec, ...pres];
    } else {
      ordenadas = candidatas.filter(r => codPlantilla(r) === CODIGO_PRES);
    }

    for (const fila of ordenadas) {
      const link = fila.querySelector('a[href*="edit-records-medical-history"]');
      if (!link) continue;
      const b64part = link.getAttribute('href').split('/').pop();
      if (decodeB64(b64part) === currentId) continue;

      log('Verificando HC...');
      const hcDoc = await fetchPage(BASE + b64part);

      // Validar que la fuente realmente sea de la plantilla esperada
      const plantSrcDetectada = detectarPlantilla(hcDoc);
      if (!plantSrcDetectada) continue;

      const cod = codPlantilla(fila);
      const tipo = cod === CODIGO_TELEC ? 'APOYO TELEFÓNICO' : 'PRESENCIAL';
      log(`HC ${tipo} encontrada.`);
      const nHC = fila.querySelector('td:nth-child(2)')?.textContent?.trim() || null;
      return { hcDoc, hcFuenteId: nHC };
    }
    return null;
  }

  async function guardarFormSYB(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    const btn = form.querySelector('button[type="submit"], input[type="submit"]');
    if (!btn) return false;
    btn.click();
    await waitAjaxIdle();
    return true;
  }

  // ── Helper genérico: abre modal histórico, filtra por HC fuente y reformula ──
  // modalSel    = selector del modal (ej: '#drugs_modal')
  // btnClass    = clase del botón reformular (ej: 'add_cart_records_history_drug')
  // tablaSel    = selector de la tabla destino (ej: '#drugs_table')
  // hcFuenteId  = id de la HC fuente para filtrar filas (columna N.HC)
  // histBtnTxt  = texto del botón que abre el modal (default 'Histórico')
  async function reformularDesdeHistorico({ modalSel, btnClass, tablaSel, hcFuenteId, tabSel, histBtnTxt = 'Histórico' }) {
    // Abrir tab si se indica
    if (tabSel) { document.querySelector(tabSel)?.click(); await sleep(400); }

    // Abrir modal histórico
    const tabContent = document.querySelector(tabSel?.replace('a[href=', '')?.replace(']', '') || 'body');
    const histBtn = Array.from(document.querySelectorAll('button'))
      .find(b => b.textContent.trim() === histBtnTxt && b.closest(modalSel?.replace('#','').replace('_modal','') || 'body') || b.textContent.trim() === histBtnTxt);

    // Buscar el botón Histórico dentro del tab activo
    const tabId = tabSel ? tabSel.match(/#(\w+)/)?.[1] : null;
    const tabEl = tabId ? document.querySelector(tabId ? `[href="${tabSel?.match(/"([^"]+)"/)?.[1]}"]` : '') : null;
    const histBtnEl = Array.from(document.querySelectorAll('button'))
      .find(b => b.textContent.trim() === histBtnTxt);

    if (!histBtnEl) { console.warn('[AutoHC] No se encontró botón Histórico para', modalSel); return { ok: 0, fail: 0 }; }

    histBtnEl.click();
    await sleep(600);

    const modal = document.querySelector(modalSel);
    if (!modal) { console.warn('[AutoHC] Modal no encontrado:', modalSel); return { ok: 0, fail: 0 }; }

    // Esperar a que el modal esté visible
    let tries = 0;
    while (!modal.classList.contains('show') && tries < 20) { await sleep(150); tries++; }

    // Filtrar filas por HC fuente (columna 0 o 1 contiene el N.HC)
    const filas = Array.from(modal.querySelectorAll('tbody tr'));
    const filasDeEstaHC = hcFuenteId
      ? filas.filter(f => f.textContent.includes(hcFuenteId))
      : filas;

    let ok = 0, fail = 0;
    const tablaBefore = (document.querySelector(tablaSel)?.querySelectorAll('tbody tr') || []).length;

    for (const fila of filasDeEstaHC) {
      // Buscar botón reformular por clase específica o por title
      const reformBtn = fila.querySelector(`button.${btnClass}`) ||
                        fila.querySelector('button[title="Reformular item"]');
      if (!reformBtn) continue;

      const rowsBefore = (document.querySelector(tablaSel)?.querySelectorAll('tbody tr') || []).length;
      reformBtn.click();
      await waitAjaxIdle();
      const rowsAfter = (document.querySelector(tablaSel)?.querySelectorAll('tbody tr') || []).length;

      if (rowsAfter > rowsBefore) { ok++; }
      else { fail++; console.warn('[AutoHC] Reformular falló para fila:', fila.textContent.trim().slice(0, 80)); }
    }

    // Cerrar modal
    const cerrar = modal.querySelector('button.close, button[data-dismiss="modal"]');
    if (cerrar) cerrar.click();
    await sleep(300);

    return { ok, fail };
  }

  async function iniciarCopiaSYB(toggles = {}) {
    const btn = document.getElementById('btn-copiar-hc');
    btn.disabled = true;
    btn.style.background = '#e65100';

    try {
      installAjaxMonitor();
      const patientId = getPatientId();
      if (!patientId) { alert('❌ No se pudo identificar el paciente.'); return; }

      const resultado = await buscarHCFuenteSYB(patientId, toggles);
      if (!resultado) { alert('❌ No se encontró HC válida anterior con los filtros activos.'); return; }

      const { hcDoc: fuenteDoc, hcFuenteId } = resultado;
      log(`N.HC fuente: ${hcFuenteId || 'no detectado'}`);

      // Detectar plantillas fuente y destino
      const plantSrc  = detectarPlantilla(fuenteDoc);
      const plantDest = detectarPlantilla(document);
      const modalidad = detectarModalidad(fuenteDoc);
      log(`Fuente: ${plantSrc} (${modalidad}) → Destino: ${plantDest}`);

      // ── Motivo (siempre) ───────────────────────────────────────────────
      log('Copiando Motivo...'); document.querySelector('a[href="#tab1"]')?.click(); await sleep(350);
      const tab1Dest = document.querySelector('#tab1'), tab1Src = fuenteDoc.querySelector('#tab1');
      const motivoSrc = tab1Src?.querySelector(`[name="${campo('motivo', plantSrc)}"]`)?.value || '';
      const enfSrc    = tab1Src?.querySelector(`[name="${campo('enfermedad', plantSrc)}"]`)?.value || '';
      setVal(tab1Dest?.querySelector(`[name="${campo('motivo', plantDest)}"]`), motivoSrc);
      setVal(tab1Dest?.querySelector(`[name="${campo('enfermedad', plantDest)}"]`), enfSrc);

      // Setear modalidad automáticamente según plantilla destino
      // Si modalidad de fuente no se pudo detectar, usar default razonable
      if (plantDest === 'pres') {
        const modVal = modalidad === 'homecare' ? '3' : '9'; // default presencial
        setVal(tab1Dest?.querySelector('select[name="reason_item_selected_1"]'), modVal);
      } else if (plantDest === 'telec') {
        const modVal = modalidad === 'videoconsulta' ? '240' : '242'; // default apoyo telefónico
        setVal(tab1Dest?.querySelector('select[name="reason_item_selected_259"]'), modVal);
      }

      const acompNombreSrc  = tab1Src?.querySelector(`[name="${campo('acompNombre', plantSrc)}"]`)?.value || '';
      const acompTelSrc     = tab1Src?.querySelector(`[name="${campo('acompTel', plantSrc)}"]`)?.value || '';
      const acompNombreDest = tab1Dest?.querySelector(`[name="${campo('acompNombre', plantDest)}"]`);
      const acompTelDest    = tab1Dest?.querySelector(`[name="${campo('acompTel', plantDest)}"]`);
      if (acompNombreDest && acompNombreSrc) setVal(acompNombreDest, acompNombreSrc);
      if (acompTelDest    && acompTelSrc)    setVal(acompTelDest, acompTelSrc);
      log('Guardando Motivo...'); await guardarFormSYB('form_update_records_history_reason');

      // ── Antecedentes (opcional) ────────────────────────────────────────
      if (toggles.antecedentes) {
        log('Copiando Antecedentes...'); document.querySelector('a[href="#tab2"]')?.click(); await sleep(350);
        const tab2Dest = document.querySelector('#tab2'), tab2Src = fuenteDoc.querySelector('#tab2');
        if (tab2Src && tab2Dest) {
          [12,14,15,16,17,18,19].forEach(id => {
            const s = tab2Src.querySelector(`textarea[name="past_item_comments_${id}"]`);
            const d = tab2Dest.querySelector(`textarea[name="past_item_comments_${id}"]`);
            if (s && d) setVal(d, s.value);
          });
          const srcChecks  = tab2Src.querySelectorAll('input[name="past_item_items_13[]"]');
          const destChecks = tab2Dest.querySelectorAll('input[name="past_item_items_13[]"]');
          const checkedVals = new Set(Array.from(srcChecks).filter(c => c.checked).map(c => c.value));
          destChecks.forEach(c => {
            const should = checkedVals.has(c.value);
            if (c.checked !== should) { c.checked = should; c.dispatchEvent(new Event('change', { bubbles: true })); }
          });
          const srcOtros = tab2Src.querySelector('input[name="past_item_14"]');
          const destOtros = tab2Dest.querySelector('input[name="past_item_14"]');
          if (srcOtros && destOtros && srcOtros.checked !== destOtros.checked) {
            destOtros.checked = srcOtros.checked;
            destOtros.dispatchEvent(new Event('change', { bubbles: true }));
          }
          log('Guardando Antecedentes...'); await guardarFormSYB('form_update_records_history_past');
        }
      }

      // ── Revisión sistemas (opcional, solo si destino es presencial) ────
      if (toggles.revisionSistemas) {
        if (plantDest === 'pres') {
          log('Copiando Revisión sistemas...'); document.querySelector('a[href="#tab3"]')?.click(); await sleep(350);
          const tab3Dest = document.querySelector('#tab3'), tab3Src = fuenteDoc.querySelector('#tab3');
          if (tab3Src && tab3Dest) {
            const cgSrc = tab3Src.querySelector('textarea[name="review_system_item_comments_20"]');
            const cgDest = tab3Dest.querySelector('textarea[name="review_system_item_comments_20"]');
            if (cgSrc && cgDest) setVal(cgDest, cgSrc.value);
            for (let id = 21; id <= 25; id++) {
              const srcCb = tab3Src.querySelector(`input[name="review_system_item_${id}"]`);
              const destCb = tab3Dest.querySelector(`input[name="review_system_item_${id}"]`);
              if (srcCb && destCb && srcCb.checked !== destCb.checked) {
                destCb.checked = srcCb.checked;
                destCb.dispatchEvent(new Event('change', { bubbles: true }));
              }
              const srcTa = tab3Src.querySelector(`textarea[name="review_system_item_comments_${id}"]`);
              const destTa = tab3Dest.querySelector(`textarea[name="review_system_item_comments_${id}"]`);
              if (srcTa && destTa) setVal(destTa, srcTa.value);
            }
            log('Guardando Revisión sistemas...'); await guardarFormSYB('form_update_records_history_review_system');
          }
        } else {
          log('Revisión sistemas omitida (plantilla teleconsulta no la tiene).');
        }
      }

      // ── Examen físico (siempre, adaptado por plantilla) ───────────────
      log('Copiando Examen físico...'); document.querySelector('a[href="#tab4"]')?.click(); await sleep(350);
      const tab4Dest = document.querySelector('#tab4'), tab4Src = fuenteDoc.querySelector('#tab4');
      ['size','weight'].forEach(name => {
        const s = tab4Src?.querySelector(`input[name="${name}"]`);
        const d = tab4Dest?.querySelector(`input[name="${name}"]`);
        if (s && d) setVal(d, s.value);
      });
      if (plantDest === 'pres') {
        ['breathing_frequency','heart_frequency','blood_pressure_systolic',
         'blood_pressure_diastolic','temperature','abdominal_perimeter'].forEach(name => {
          const s = tab4Src?.querySelector(`input[name="${name}"]`);
          const d = tab4Dest?.querySelector(`input[name="${name}"]`);
          if (s && d) setVal(d, s.value);
        });
        setVal(tab4Dest.querySelector('select[name="physic_exam_item_selected_78"]'), '105');
        for (let id = 79; id <= 88; id++) {
          const s = tab4Src?.querySelector(`textarea[name="physic_exam_item_comments_${id}"]`);
          const d = tab4Dest?.querySelector(`textarea[name="physic_exam_item_comments_${id}"]`);
          if (s && d) setVal(d, s.value);
        }
        const bSrc = tab4Src?.querySelector('input[name="barthel"]');
        const bDest = tab4Dest?.querySelector('input[name="barthel"]');
        if (bSrc && bDest) setVal(bDest, bSrc.value);
        const fSrc = tab4Src?.querySelector('select[name="fac"]');
        const fDest = tab4Dest?.querySelector('select[name="fac"]');
        if (fSrc && fDest) setVal(fDest, fSrc.value);
      }
      log('Guardando Examen físico...'); await guardarFormSYB('form_update_records_history_physic_exam');

      // ── Análisis (siempre, con mapeo por plantilla) ────────────────────
      log('Copiando Análisis...'); document.querySelector('a[href="#tab5"]')?.click(); await sleep(350);
      const tab5Dest = document.querySelector('#tab5'), tab5Src = fuenteDoc.querySelector('#tab5');
      const analisisSrc = tab5Src?.querySelector(`textarea[name="${campo('analisis', plantSrc)}"]`)?.value || '';
      setVal(tab5Dest?.querySelector(`textarea[name="${campo('analisis', plantDest)}"]`), analisisSrc);
      const seguimientoVal = plantDest === 'telec' ? VALS.telec.mensual : VALS.pres.mensual;
      setVal(tab5Dest?.querySelector(`select[name="${campo('seguimiento', plantDest)}"]`), seguimientoVal);
      const proximoVal = plantDest === 'telec' ? VALS.telec.presencial : VALS.pres.presencial;
      setVal(tab5Dest?.querySelector(`select[name="${campo('proximoCtrl', plantDest)}"]`), proximoVal);
      log('Guardando Análisis...'); await guardarFormSYB('form_update_medical_record_analysis');

      // ── Diagnósticos (siempre) ─────────────────────────────────────────
      log('Abriendo Diagnósticos...'); document.querySelector('a[href="#tab6"]')?.click(); await sleep(450);
      const histBtn2 = Array.from(document.querySelectorAll('#tab6 button')).find(b => b.textContent.trim() === 'Histórico');
      if (histBtn2) {
        histBtn2.click(); await sleep(500);
        const modal2 = document.querySelector('#diagnosis_modal');
        let tries = 0;
        while (modal2 && !modal2.classList.contains('show') && tries < 20) { await sleep(150); tries++; }
        if (modal2) {
          let ok = false;
          for (const fila of Array.from(modal2.querySelectorAll('tbody tr'))) {
            const t = fila.textContent.toUpperCase();
            if (!t.includes('HISTORIA CLINICA DE MEDICINA GENERAL') || t.includes('NOTA ACLARATORIA') || t.includes('EGRESO POR FALLECIMIENTO')) continue;
            const addBtn = fila.querySelector('button.add_record_history_diagnosis');
            if (addBtn) { addBtn.click(); ok = true; await waitAjaxIdle(); break; }
          }
          const cerrar2 = modal2.querySelector('button.close, button[data-dismiss="modal"]');
          if (cerrar2) cerrar2.click(); await sleep(300);
          if (!ok) alert('⚠️ No se encontró diagnóstico anterior en el histórico.');
        }
      }
      log('Guardando Diagnósticos...'); await guardarFormSYB('form_update_records_history_diagnosis');

      // ── Exámenes (toggle) ──────────────────────────────────────────────
      if (toggles.examenes) {
        log('Copiando Exámenes...');
        document.querySelector('a[href="#tab8"]')?.click(); await sleep(400);
        const { ok: okEx, fail: failEx } = await reformularDesdeHistorico({ modalSel: '#exams_modal', btnClass: 'add_cart_records_history_exams', tablaSel: '#exams_table', hcFuenteId });
        log(`Exámenes: ${okEx} ok, ${failEx} fallaron`);
        await guardarFormSYB('form_update_records_history_exams');
      }

      // ── Medicamentos (toggle) ──────────────────────────────────────────
      if (toggles.medicamentos) {
        log('Copiando Medicamentos...');
        document.querySelector('a[href="#tab9"]')?.click(); await sleep(400);
        const { ok: okDr, fail: failDr } = await reformularDesdeHistorico({ modalSel: '#drugs_modal', btnClass: 'add_cart_records_history_drug', tablaSel: '#drugs_table', hcFuenteId });
        log(`Medicamentos: ${okDr} ok, ${failDr} fallaron`);
        if (failDr > 0) alert(`⚠️ ${failDr} medicamento(s) no se pudieron agregar. Revisa el tab de Medicamentos.`);
        await guardarFormSYB('form_update_records_history_drugs');
      }

      // ── Interconsultas (toggle) ────────────────────────────────────────
      if (toggles.interconsultas) {
        log('Copiando Interconsultas...');
        document.querySelector('a[href="#tab11"]')?.click(); await sleep(400);
        const { ok: okTr, fail: failTr } = await reformularDesdeHistorico({ modalSel: '#transfers_modal', btnClass: 'add_cart_records_history_transfer', tablaSel: '#transfers_table', hcFuenteId });
        log(`Interconsultas: ${okTr} ok, ${failTr} fallaron`);
        await guardarFormSYB('form_update_records_history_transfers');
      }

      // ── Insumos (toggle) ───────────────────────────────────────────────
      if (toggles.insumos) {
        log('Copiando Insumos...');
        document.querySelector('a[href="#tab12"]')?.click(); await sleep(400);
        const { ok: okSu, fail: failSu } = await reformularDesdeHistorico({ modalSel: '#supplies_modal', btnClass: 'add_cart_records_history_supply', tablaSel: '#supplies_table', hcFuenteId });
        log(`Insumos: ${okSu} ok, ${failSu} fallaron`);
        await guardarFormSYB('form_update_records_history_supplies');
      }

      // ── Paquetes (toggle) ──────────────────────────────────────────────
      if (toggles.paquetes) {
        log('Copiando Paquetes...');
        document.querySelector('a[href="#tab14"]')?.click(); await sleep(400);
        const { ok: okPk, fail: failPk } = await reformularDesdeHistorico({ modalSel: '#packages_modal', btnClass: 'add_cart_records_history_package', tablaSel: '#packages_table', hcFuenteId });
        log(`Paquetes: ${okPk} ok, ${failPk} fallaron`);
        await guardarFormSYB('form_update_records_history_packages');
      }

      // ── Decisiones (toggle) ────────────────────────────────────────────
      if (toggles.decisiones) {
        log('Copiando Decisiones...');
        document.querySelector('a[href="#tab13"]')?.click(); await sleep(400);
        const { ok: okDe, fail: failDe } = await reformularDesdeHistorico({ modalSel: '#decisions_modal', btnClass: 'add_cart_records_history_decision', tablaSel: '#decisions_table', hcFuenteId });
        log(`Decisiones: ${okDe} ok, ${failDe} fallaron`);
        await guardarFormSYB('form_update_records_history_decisions');
      }

      // ── Plan (siempre, con mapeo por plantilla) ────────────────────────
      log('Copiando Plan...'); document.querySelector('a[href="#tab7"]')?.click(); await sleep(350);
      const tab7Dest = document.querySelector('#tab7'), tab7Src = fuenteDoc.querySelector('#tab7');
      const planSrc  = tab7Src?.querySelector(`textarea[name="${campo('plan', plantSrc)}"]`)?.value || '';
      const planDest = tab7Dest?.querySelector(`textarea[name="${campo('plan', plantDest)}"]`);
      if (planDest && planSrc?.trim()) appendVal(planDest, planSrc);
      log('Guardando Plan...'); await guardarFormSYB('form_update_medical_record_plan');

      btn.textContent = '✓ Listo';
      window.dispatchEvent(new CustomEvent('autohc:done'));
    } catch(err) {
      console.error('[AutoHC SYB]', err); alert('❌ Error: ' + err.message);
      window.dispatchEvent(new CustomEvent('autohc:done'));
    }
  }

  // ── Listener: cuando el content.js dispara el evento, ejecutamos la copia ──
  window.addEventListener('autohc:start', (e) => {
    const modo = e.detail?.modo;
    const toggles = e.detail?.toggles || {};
    if (modo === 'MTD') iniciarCopiaMTD();
    else if (modo === 'SYB') iniciarCopiaSYB(toggles);
    else alert('⚠️ No se pudo detectar el tipo de historia clínica.');
  });

  // ── Listener: aplicar plantilla ───────────────────────────────────────────
  window.addEventListener('autohc:plantilla', async (e) => {
    const sesion = e.detail?.sesion;
    if (!sesion) { alert('❌ Sin sesión activa.'); return; }

    const epsActual  = detectarEPS();
    const plantDest  = detectarPlantilla(document);

    let plantillas = [];
    try {
      const resp = await fetch(`https://hc-licencias.hc-gestiona.workers.dev/plantillas?medico=${encodeURIComponent(sesion.medico_id)}&clave=${encodeURIComponent(sesion.clave)}`);
      const data = await resp.json();
      plantillas = (data.plantillas || []).filter(p => (p.eps || 'SYB') === epsActual);
    } catch(e) {
      alert('❌ No se pudieron cargar las plantillas.'); return;
    }

    if (plantillas.length === 0) {
      alert(`No tienes plantillas guardadas para ${epsActual}. Créalas desde el popup de AutoHC.`); return;
    }

    const modalDiv = document.createElement('div');
    modalDiv.id = 'autohc-plantilla-modal';
    modalDiv.style.cssText = `position:fixed;inset:0;z-index:999999;background:rgba(10,10,10,0.5);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;font-family:'Geist',-apple-system,sans-serif;`;

    modalDiv.innerHTML = `
      <div style="background:#fafafa;width:340px;box-shadow:0 32px 80px rgba(0,0,0,0.25);-webkit-font-smoothing:antialiased;">
        <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 20px 10px;border-bottom:1px solid #e6e6e1;">
          <span style="font-family:'Geist',sans-serif;font-weight:700;font-size:13px;letter-spacing:-0.01em;">Aplicar plantilla · ${epsActual}</span>
          <button id="autohc-plantilla-cerrar" style="background:none;border:none;cursor:pointer;font-size:18px;color:#999;line-height:1;">×</button>
        </div>
        <div style="padding:14px 20px 18px;">
          <div style="font-family:'Geist Mono',monospace;font-size:9px;color:#525252;text-transform:uppercase;letter-spacing:0.14em;margin-bottom:8px;">Selecciona una plantilla</div>
          ${plantillas.map(p => {
            const compatible = epsActual === 'MTD' ||
              (p.modalidad === 'pres' && plantDest === 'pres') ||
              (p.modalidad === 'telec' && plantDest === 'telec');
            const modLabel = epsActual === 'MTD' ? 'Presencial' : (p.modalidad === 'telec' ? 'Teleconsulta' : 'Presencial');
            return `<div style="display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid #e6e6e1;">
              <div>
                <div style="font-family:'Geist',sans-serif;font-size:12px;font-weight:500;color:#0a0a0a;">${p.nombre}</div>
                <div style="font-family:'Geist Mono',monospace;font-size:9px;color:${compatible ? '#00875f' : '#d4302a'};">${modLabel}${compatible ? '' : ' · ⚠️ diferente modalidad'}</div>
              </div>
              <button class="autohc-aplicar-plantilla" data-nombre="${p.nombre}"
                style="font-family:'Geist',sans-serif;font-size:11px;font-weight:600;color:white;background:#0040dd;border:none;padding:6px 12px;cursor:pointer;">
                Aplicar
              </button>
            </div>`;
          }).join('')}
        </div>
      </div>`;

    document.body.appendChild(modalDiv);
    document.getElementById('autohc-plantilla-cerrar').addEventListener('click', () => modalDiv.remove());
    modalDiv.addEventListener('click', ev => { if (ev.target === modalDiv) modalDiv.remove(); });

    modalDiv.querySelectorAll('.autohc-aplicar-plantilla').forEach(btn => {
      btn.addEventListener('click', async () => {
        const nombre = btn.dataset.nombre;
        const plantilla = plantillas.find(p => p.nombre === nombre);
        if (!plantilla) return;

        const compatible = epsActual === 'MTD' ||
          (plantilla.modalidad === 'pres' && plantDest === 'pres') ||
          (plantilla.modalidad === 'telec' && plantDest === 'telec');

        if (!compatible && plantDest !== null) {
          const ok = confirm(`⚠️ Esta plantilla es para ${plantilla.modalidad === 'telec' ? 'Teleconsulta' : 'Presencial'} pero estás en una HC ${plantDest === 'telec' ? 'Teleconsulta' : 'Presencial'}. Solo se pegarán los campos compatibles. ¿Continuar?`);
          if (!ok) return;
        }

        modalDiv.remove();
        if (epsActual === 'MTD') await aplicarPlantillaMTD(plantilla);
        else await aplicarPlantilla(plantilla, plantDest);
      });
    });
  });

  async function aplicarPlantilla(plantilla, plantDest) {
    const btn = document.getElementById('btn-copiar-hc');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Aplicando plantilla...'; }

    try {
      const c = plantilla.campos;
      const pd = plantDest || plantilla.modalidad; // si no detecta, usa la de la plantilla

      // ── Motivo ─────────────────────────────────────────────────
      log('Aplicando Motivo...');
      document.querySelector('a[href="#tab1"]')?.click(); await sleep(350);
      const tab1 = document.querySelector('#tab1');
      if (c.motivo)     setVal(tab1?.querySelector(`[name="${campo('motivo', pd)}"]`), c.motivo);
      if (c.enfermedad) setVal(tab1?.querySelector(`[name="${campo('enfermedad', pd)}"]`), c.enfermedad);
      await guardarFormSYB('form_update_records_history_reason');

      // ── Examen físico ─────────────────────────────────────────
      log('Aplicando Examen físico...');
      document.querySelector('a[href="#tab4"]')?.click(); await sleep(350);
      const tab4 = document.querySelector('#tab4');
      if (c.talla) setVal(tab4?.querySelector('input[name="size"]'),   c.talla);
      if (c.peso)  setVal(tab4?.querySelector('input[name="weight"]'), c.peso);

      // Signos vitales solo si destino es presencial y plantilla es presencial
      if (pd === 'pres' && plantilla.modalidad === 'pres') {
        if (c.fr)     setVal(tab4?.querySelector('input[name="breathing_frequency"]'),      c.fr);
        if (c.fc)     setVal(tab4?.querySelector('input[name="heart_frequency"]'),          c.fc);
        if (c.tas)    setVal(tab4?.querySelector('input[name="blood_pressure_systolic"]'),  c.tas);
        if (c.tad)    setVal(tab4?.querySelector('input[name="blood_pressure_diastolic"]'), c.tad);
        if (c.temp)   setVal(tab4?.querySelector('input[name="temperature"]'),              c.temp);
        if (c.aspecto) setVal(tab4?.querySelector('select[name="physic_exam_item_selected_78"]'), c.aspecto);
        // Textareas detallados EF
        if (c.ef && typeof c.ef === 'object') {
          Object.entries(c.ef).forEach(([id, val]) => {
            const el = tab4?.querySelector(`textarea[name="physic_exam_item_comments_${id}"]`);
            if (el && val) setVal(el, val);
          });
        }
      }
      await guardarFormSYB('form_update_records_history_physic_exam');

      // ── Análisis ───────────────────────────────────────────────
      if (c.analisis) {
        log('Aplicando Análisis...');
        document.querySelector('a[href="#tab5"]')?.click(); await sleep(350);
        const tab5 = document.querySelector('#tab5');
        setVal(tab5?.querySelector(`textarea[name="${campo('analisis', pd)}"]`), c.analisis);
        await guardarFormSYB('form_update_medical_record_analysis');
      }

      // ── Plan ───────────────────────────────────────────────────
      if (c.plan) {
        log('Aplicando Plan...');
        document.querySelector('a[href="#tab7"]')?.click(); await sleep(350);
        const tab7 = document.querySelector('#tab7');
        setVal(tab7?.querySelector(`textarea[name="${campo('plan', pd)}"]`), c.plan);
        await guardarFormSYB('form_update_medical_record_plan');
      }

      if (btn) { btn.textContent = '✓ Plantilla aplicada'; }
      setTimeout(() => window.dispatchEvent(new CustomEvent('autohc:done')), 1500);

    } catch(err) {
      console.error('[AutoHC Plantilla]', err);
      alert('❌ Error aplicando plantilla: ' + err.message);
      window.dispatchEvent(new CustomEvent('autohc:done'));
    }
  }

  async function aplicarPlantillaMTD(plantilla) {
    const btn = document.getElementById('btn-copiar-hc');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Aplicando plantilla...'; }

    try {
      const c = plantilla.campos;

      // ── Motivo ─────────────────────────────────────────────────
      log('Aplicando Motivo MTD...');
      document.querySelector('a[href="#tab1"]')?.click(); await sleep(350);
      // Motivo de consulta = textarea plana reason_item_comments_2
      if (c.motivo) {
        const el = document.querySelector('textarea[name="reason_item_comments_2"]');
        if (el) setVal(el, c.motivo);
      }
      // Enfermedad actual = TinyMCE reason_item_comments_1
      if (c.enfermedad) setTinyOrTextarea('reason_item_comments_1', c.enfermedad);
      await guardarForm('form_update_records_history_reason');

      // ── Examen físico ─────────────────────────────────────────
      log('Aplicando Examen físico MTD...');
      document.querySelector('a[href="#tab4"]')?.click(); await sleep(350);
      const tab4 = document.querySelector('#tab4');
      if (c.talla) setVal(tab4?.querySelector('input[name="size"]'),   c.talla);
      if (c.peso)  setVal(tab4?.querySelector('input[name="weight"]'), c.peso);
      if (c.fr)    setVal(tab4?.querySelector('input[name="breathing_frequency"]'),      c.fr);
      if (c.fc)    setVal(tab4?.querySelector('input[name="heart_frequency"]'),          c.fc);
      if (c.tas)   setVal(tab4?.querySelector('input[name="blood_pressure_systolic"]'),  c.tas);
      if (c.tad)   setVal(tab4?.querySelector('input[name="blood_pressure_diastolic"]'), c.tad);
      if (c.temp)  setVal(tab4?.querySelector('input[name="temperature"]'),              c.temp);
      if (c.aspecto) setVal(tab4?.querySelector('select[name="physic_exam_item_selected_1691"]'), c.aspecto);
      if (c.ef && typeof c.ef === 'object') {
        Object.entries(c.ef).forEach(([id, val]) => {
          const el = tab4?.querySelector(`textarea[name="physic_exam_item_comments_${id}"]`);
          if (el && val) setVal(el, val);
        });
      }
      await guardarForm('form_update_records_history_physic_exam', 1500);

      // ── Análisis ───────────────────────────────────────────────
      if (c.analisis) {
        log('Aplicando Análisis MTD...');
        document.querySelector('a[href="#tab5"]')?.click(); await sleep(350);
        setTinyOrTextarea('analysis_item_comments_6', c.analisis);
        await guardarForm('form_update_medical_record_analysis');
      }

      if (btn) { btn.textContent = '✓ Plantilla aplicada'; }
      setTimeout(() => window.dispatchEvent(new CustomEvent('autohc:done')), 1500);

    } catch(err) {
      console.error('[AutoHC Plantilla MTD]', err);
      alert('❌ Error aplicando plantilla: ' + err.message);
      window.dispatchEvent(new CustomEvent('autohc:done'));
    }
  }

  console.log('[AutoHC] Inyector cargado en el contexto de la página');
})();
